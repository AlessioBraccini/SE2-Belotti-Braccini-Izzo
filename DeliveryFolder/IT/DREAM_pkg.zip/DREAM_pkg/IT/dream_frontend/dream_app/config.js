// Use it for online backend
export let serverUrl = 'https://appdream.herokuapp.com'

// Use this for the local backend
// export let serverUrl = 'http://localhost:8000'  // Or any port number