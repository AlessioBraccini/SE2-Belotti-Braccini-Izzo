<template>
farmerHome
</template>

<script>
export default {
  name: "FarmerHome"
}
</script>

<style scoped>

</style>