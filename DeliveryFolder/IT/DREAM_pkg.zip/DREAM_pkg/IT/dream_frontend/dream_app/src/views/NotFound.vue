<template>
  <h1 style="text-align: center; margin-top: 50px">Sorry, the page you search doesn't exist</h1>
</template>

<script>
export default {
  name: "NotFound"
}
</script>

<style scoped>

</style>