<template>
  <SignUpForm class="form"/>
</template>

<script>

import SignUpForm from "@/views/SignUpForm";

export default {
  name: "Home",
  components:{
    SignUpForm
  }
}
</script>

<style scoped>

</style>