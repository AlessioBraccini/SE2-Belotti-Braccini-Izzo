<template style="margin-left: 20px">
  Site created by: <br>
  Frontend: Alessio Braccini <br>
  Backend: Ottavia Belotti, Riccardo Izzo
</template>

<script>
export default {
  name: "About"
}
</script>

<style scoped>

</style>