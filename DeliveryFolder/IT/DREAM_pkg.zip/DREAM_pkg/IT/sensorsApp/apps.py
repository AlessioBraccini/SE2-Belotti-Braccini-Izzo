from django.apps import AppConfig


class SensorsappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sensorsApp'
