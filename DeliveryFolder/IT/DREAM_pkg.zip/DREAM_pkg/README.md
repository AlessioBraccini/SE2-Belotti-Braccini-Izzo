# DREAM installation

## Requirements
**Node.js** is required in order to run the frontend, please install it if you don’t have it on your device.
To run the backend, **Python 3.10** or a compatible version is mandatory. Moreover, `pip` command must be installed too, in order to resolve the project’s dependencies.
A **PostgreSQL database** must be set and running as well. 

### Python and Pip
– Download Python 3.10 or equivalent from https://www.python.org/downloads/
– Install latest version of Pip referencing https://pip.pypa.io/en/stable/installation/

### Node.js
– Download the latest version of Node.js https://nodejs.org/it/download/

### PostgreSQL
– Download the installer of the latest version from https://www.postgresql.org/download/ for your OS

## Backend installation
1) Download the latest zip archive from the _Release Page_ on the project’s GitHub repository
2) Extract all the files in the same folder
3) Create a .env file in the same folder with the following fields and fill it:
    i. `SECRET_KEY` is the key used by Django to manage authentication and hashing messages. You can set your own.
    ii. `DATABASE_NAME`, `DATABASE_USER` and `DATABASE_PWD` are credential to access your local PostgreSQL database. If you wish to use a not local PostgreSQL database, you can also provide the DATABASE_URL variable.
    iii. `LOCAL_STATIC_FILES` can be set either to True or False to indicate if you want to store static files locally or on Google Drive.
        * If True (or not set), then the Steering Initiatives reports uploaded to the app will be stored in `generated/reports`
        * If False, then the reports are going to be stored on Google Drive (refer to next point)
    iv. `GOOGLE_DRIVE_STORAGE_JSON_KEY_FILE_CONTENTS` and `GOOGLE_ DRIVE_STORAGE_SERVICE_MAIL` must be set if `LOCAL_STATIC_ FILES=false`. This happens because a Google Drive API is going to be used to store static files. You have to:
        * Create a service account on a project in Google Developers Console: this will be your service email
        * Generate a secret service key a store it in a safe place. Copy and paste its content in the JSON Key variable

```shell
SECRET_KEY=your_backend_secret_key

DATABASE_NAME=your_database_name
DATABASE_USER=your_database_admin_username
DATABASE_PWD=your_database_password

LOCAL_STATIC_FILES=true/false

# if LOCAL_STATIC_FILE=false then the following variables must be set as well
GOOGLE_DRIVE_STORAGE_JSON_KEY_FILE_CONTENTS={your_JSON_format_key_file_content_for_Google_Drive_API}
GOOGLE_DRIVE_STORAGE_SERVICE_EMAIL=your_project.iam.gserviceaccount.command
```

4) Save .env
5) Make sure you have your PostgreSQL database ready and running
6a) If you are on a Unix-like system (Linux-DebianorMacOS) with bash/zsh shell, you can run the Makefile in the dream_pkg via make run command: this will install all the dependencies, update the database schema and start the backend server. However, if you wish to do that manually, you can follow the commands below:

```shell
# create virtual environment dream_pkg:~$ python3 -m venv IT/venv
# activate venv
dream_pkg:~$ source IT/venv/bin/activate
# install dependencies
dream_pkg:~$ pip install -r IT/requirements.txt
# update database schema
dream_pkg:~$ python3 IT/manage.py makemigrations
dream_pkg:~$ python3 IT/manage.py migrate
 # start backend server
dream_pkg:~$ python3 IT/manage.py runserver
```

6b) If you are on Windows, run the following commands:

```shell
# create a new virtual environment
C:\dream_pkg\> python -m venv c:\dream_pkg\IT\venv
# activate venv: 2 options
C:\dream_pkg\> IT\venv\Scripts\activate.bat #for cmd
.exe
PS C:\dream_pkg\> IT\venv\Scripts\Activate.ps1 #for
PowerShell
# install dependencies
C:\dream_pkg\> pip install -r IT\requirements.txt 
# update database schema
C:\dream_pkg\> python IT/manage.py makemigrations C:\dream_pkg\> python IT/manage.py migrate
# start backend server
C:\dream_pkg\> python IT/manage.py runserver
```

## Frontend installation
Firstly, you have to specify in the config.js file (contained in IT/dream_frontend/dream_app) if you want to run the backend online or locally on your device. Inside the file you will find a configuration string and you have to insert the url of the chosen backend (by default is set to online backend but some choices are already available).

1) Open a terminal and move to dream_app folder 
2) Run npm run build command
3) Move to dist folder
4) Run serve dist command
5) Follow the instructions



